#!/bin/sh
# Detect the firmware userland ABI. uname alone can report a 64-bit kernel
# running a 32-bit firmware.
probe="$1"
bits="$("$probe" elf-class /bin/busybox 2>/dev/null || "$probe" elf-class /bin/sh)" || exit 1
machine="$(uname -m)"
platform_hint="$(
    for key in odmpid productid build_name soc productid_hw; do nvram get "$key"; done
    if [ -r /proc/device-tree/compatible ]; then tr '\000' '\n' </proc/device-tree/compatible; fi
    cat /proc/cpuinfo 2>/dev/null
)"
platform_hint="$(printf '%s' "$platform_hint" | tr '[:upper:]' '[:lower:]')"
case "$machine:$bits" in
    aarch64:2|arm64:2) abi=arm64 ;;
    arm*:1|aarch64:1) abi=armv7 ;;
    *) echo 'Unsupported firmware ABI' >&2; exit 1 ;;
esac
case "$platform_hint" in
    *ipq53*|*ipq54*|*bd4*|*be6500*|*tuf_6500*)
        if [ "$abi" = arm64 ]; then platform=ipq64; else platform=ipq32; fi ;;
    *mt798*|*mt799*|*tx-ax6000*|*tuf-ax4200q*|*zenwifi_bt8p*|*gs7*|*rt-ax57_go*|*gs-be7200x*) platform=mtk ;;
    *ipq807*|*ipq806*|*rt-ax89x*) platform=qca ;;
    *)
        case "$abi:$(uname -r)" in
            armv7:2.6.*|armv7:3.*) platform=arm ;;
            armv7:*) platform=hnd ;;
            arm64:*) platform=hnd_v8 ;;
        esac ;;
esac
printf '%s %s\n' "$platform" "$abi"
