<!doctype html>
<html lang="zh-Hans">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; object-src 'none'; base-uri 'none'; form-action 'self'">
<title>壁虎 Behoo · 软件中心</title>
<link rel="stylesheet" href="/index_style.css">
<link rel="stylesheet" href="/form_style.css">
<link rel="stylesheet" href="/usp_style.css">
<script src="/js/jquery.js"></script>
<script src="/js/httpApi.js"></script>
<script src="/state.js"></script>
<script src="/general.js"></script>
<script src="/popup.js"></script>
<script src="/help.js"></script>
<style>
#behoo {
  color-scheme: light;
  width: 760px; max-width: 100%; margin: 0 0 12px;
  background: var(--canvas); color: var(--ink); font-size: 14px; line-height: 1.45;
  border-radius: 12px;
  --canvas: #f4f6fa; --panel: #fff; --surface: #f6f8fc;
  --line: #e0e7f0; --ink: #172334; --muted: #52627a; --subtle: #6b7a90;
  --accent: #0b61cf; --blue: #0d69e4; --soft: #e7f0ff; --strong: #153f75;
  --green: #167348; --green-soft: #e5f6ec; --power: #218556; --amber: #986021;
  --red: #a1243c; --red-soft: #ffedf0; --chart-down: #2477e7; --chart-up: #2a9368;
  --hero: #eaf3ff; --shadow: 0 2px 5px #17263b06; --on-blue: #fff;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", "Segoe UI", sans-serif;
}
#behoo[data-theme="dark"] {
  color-scheme: dark;
  --canvas: #131821; --panel: #1c2532; --surface: #242f40;
  --line: #354257; --ink: #f3f6fc; --muted: #b0bdd0; --subtle: #9aacc6;
  --accent: #9ccaff; --blue: #81b9ff; --soft: #233d5e; --strong: #bbd8ff;
  --green: #8ee0b2; --green-soft: #203c37; --power: #75d5a3; --amber: #efd0a4;
  --red: #ffadb7; --red-soft: #472834; --chart-down: #72b2ff; --chart-up: #70cea4;
  --hero: #263b55; --shadow: 0 2px 5px #0002; --on-blue: #081529;
}
#behoo * { box-sizing: border-box; }
#behoo [hidden] { display: none !important; }

#behoo h1, #behoo h2, #behoo h3, #behoo p, #behoo dl, #behoo dd { margin: 0; }
#behoo h1 { font-size: 24px; line-height: 1.25; letter-spacing: -.045em; }
#behoo h2 { font-size: 17px; line-height: 1.4; }
#behoo h3 { font-size: 14px; }
#behoo button, #behoo input, #behoo select { font: inherit; }
#behoo button { cursor: pointer; }
#behoo button:disabled { opacity: .55; cursor: default; }
#behoo :focus-visible { outline: 3px solid var(--blue); outline-offset: 3px; }
#behoo .icon { width: 19px; height: 19px; flex: none; fill: none; stroke: currentColor; stroke-width: 1.7; stroke-linecap: round; stroke-linejoin: round; }
#behoo .icon.small { width: 16px; height: 16px; }
#behoo .muted { color: var(--muted); font-size: 13px; line-height: 1.55; }
#behoo .micro { color: var(--subtle); font-size: 12px; line-height: 1.5; }
#behoo .mono { font-family: ui-monospace, Menlo, monospace; font-variant-numeric: tabular-nums; }
#behoo .brand { display: flex; align-items: center; gap: 9px; }
#behoo .brand img { width: 36px; height: 36px; object-fit: contain; border-radius: 10px; }
#behoo .brand strong { display: block; font-size: 16px; }
#behoo .brand a { display: inline-block; color: var(--accent); text-decoration: none; }
#behoo .brand a:hover { text-decoration: underline; }
#behoo .plugin-header { padding: 15px 18px 0; border-bottom: 1px solid var(--line); background: var(--panel); border-radius: 12px 12px 0 0; }
#behoo .plugin-header .row { align-items: start; }
#behoo .plugin-tabs { display: flex; gap: 4px; margin-top: 12px; overflow-x: auto; }
#behoo .plugin-tabs button { display: flex; align-items: center; gap: 6px; flex: none; padding: 10px 8px; border: 0; border-bottom: 2px solid transparent; color: var(--muted); background: transparent; white-space: nowrap; }
#behoo .plugin-tabs button:hover, #behoo .plugin-tabs button[aria-current="page"] { color: var(--accent); border-bottom-color: var(--accent); }
#behoo .plugin-tabs button[aria-current="page"] { font-weight: 700; }
#behoo .plugin-tabs .icon { width: 16px; height: 16px; }
#behoo main { width: 100%; padding: 21px 18px 24px; }
#behoo .page-header, #behoo .section-heading, #behoo .row, #behoo .actions { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
#behoo .page-header { margin-bottom: 22px; }
#behoo .actions { gap: 8px; justify-content: flex-end; flex-wrap: wrap; }
#behoo .status-tag { display: inline-flex; align-items: center; gap: 6px; padding: 4px 9px; border-radius: 6px; font-size: 11px; font-weight: 650; color: var(--muted); background: var(--surface); border: 1px solid var(--line); white-space: nowrap; }
#behoo .button { display: inline-flex; align-items: center; justify-content: center; gap: 7px; min-height: 37px; padding: 7px 13px; border: 1px solid var(--line); border-radius: 9px; background: var(--panel); color: var(--ink); font-weight: 650; font-size: 13px; white-space: nowrap; }
#behoo .button:hover { border-color: var(--accent); }
#behoo .button.primary { background: var(--blue); color: var(--on-blue); border-color: transparent; box-shadow: 0 2px 4px #0d69e420; }
#behoo .button.text { color: var(--accent); border-color: transparent; background: transparent; padding-inline: 6px; }
#behoo .button.text:hover { background: var(--soft); }
#behoo .button.danger { background: var(--red-soft); color: var(--red); border-color: transparent; }
#behoo .button.icon-button { width: 37px; padding: 0; }
#behoo .panel { background: var(--panel); border: 1px solid var(--line); border-radius: 17px; box-shadow: var(--shadow); min-width: 0; }
#behoo .panel-pad { padding: 21px 23px; }
#behoo .stack { display: grid; gap: 16px; }
#behoo .hero { display: grid; grid-template-columns: minmax(0, 1fr) 128px; align-items: center; min-height: 178px; padding: 18px 24px; background: radial-gradient(ellipse at 91% 47%, var(--hero), transparent 64%), linear-gradient(110deg, var(--panel) 38%, var(--hero)); }
#behoo .hero-copy { min-width: 0; }
#behoo .hero-kicker { display: flex; align-items: center; gap: 7px; color: var(--muted); font-size: 13px; font-weight: 650; margin-bottom: 7px; }
#behoo .hero-kicker .icon { color: var(--accent); }
#behoo .state { font-size: 34px; line-height: 1.2; letter-spacing: -.045em; }
#behoo .state.connected { color: var(--green); }
#behoo .hero-note { margin-top: 7px; }
#behoo .hero-summary { display: flex; flex-wrap: wrap; gap: 8px 22px; margin-top: 17px; }
#behoo .hero-summary div { display: flex; align-items: center; gap: 6px; min-width: 0; }
#behoo .hero-summary dt { color: var(--muted); font-size: 12px; }
#behoo .hero-summary dd { font-size: 12px; font-weight: 660; overflow-wrap: anywhere; }
#behoo .power-area { display: grid; justify-items: center; gap: 13px; }
#behoo .power { display: grid; place-items: center; width: 79px; height: 79px; border: 0; border-radius: 50%; background: var(--soft); color: var(--accent); box-shadow: 0 0 0 8px color-mix(in srgb, var(--accent) 11%, transparent), 0 0 0 17px color-mix(in srgb, var(--accent) 4%, transparent); transition: transform .18s, background .18s; }
#behoo .power .icon { width: 33px; height: 33px; stroke-width: 1.8; }
#behoo .power:hover { transform: scale(1.04); }
#behoo .power[aria-pressed="true"] { background: var(--power); color: var(--on-blue); box-shadow: 0 0 0 8px color-mix(in srgb, var(--power) 16%, transparent), 0 0 0 17px color-mix(in srgb, var(--power) 6%, transparent); }
#behoo .power-caption { margin-top: 8px; font-size: 12px; font-weight: 650; color: var(--muted); }
#behoo .overview-grid { display: grid; grid-template-columns: minmax(0, 1.65fr) minmax(0, 1fr); gap: 16px; }
#behoo .traffic { display: grid; align-content: start; gap: 13px; }
#behoo .traffic-values { display: flex; flex-wrap: wrap; column-gap: 27px; row-gap: 8px; }
#behoo .traffic-value { display: grid; gap: 3px; }
#behoo .traffic-value strong { font-size: 19px; font-variant-numeric: tabular-nums; letter-spacing: -.025em; }
#behoo .traffic-value span { font-size: 12px; color: var(--muted); display: flex; align-items: center; gap: 6px; }
#behoo .dot { display: inline-block; width: 7px; height: 7px; flex: none; border-radius: 50%; background: var(--subtle); }
#behoo .dot.green { background: var(--green); }
#behoo .dot.down { background: var(--chart-down); }
#behoo .dot.up { background: var(--chart-up); }
#behoo #chart { display: block; width: 100%; height: 80px; }
#behoo .chart-axis { display: flex; justify-content: space-between; color: var(--subtle); font-size: 11px; }
#behoo .profile-summary { display: grid; gap: 12px; align-content: start; }
#behoo .summary-list > div, #behoo .detail-list > div { display: grid; grid-template-columns: minmax(90px, 1fr) minmax(0, 1.3fr); gap: 12px; padding: 10px 0; border-top: 1px solid var(--line); align-items: baseline; }
#behoo .summary-list dt, #behoo .detail-list dt { color: var(--muted); font-size: 13px; }
#behoo .summary-list dd, #behoo .detail-list dd { font-weight: 650; text-align: end; overflow-wrap: anywhere; }
#behoo .table-wrap { overflow-x: auto; }
#behoo table { width: 100%; border-collapse: collapse; text-align: start; }
#behoo th { color: var(--subtle); font-size: 12px; font-weight: 650; }
#behoo th, #behoo td { text-align: start; padding: 10px 13px 10px 0; white-space: nowrap; }
#behoo td { border-top: 1px solid var(--line); }
#behoo td:last-child, #behoo th:last-child { padding-right: 0; }
#behoo .device-name { display: flex; align-items: center; gap: 9px; font-weight: 660; }
#behoo .device-name .icon { color: var(--muted); }
#behoo .tag { display: inline-flex; gap: 6px; align-items: center; border-radius: 6px; padding: 4px 8px; background: var(--surface); color: var(--muted); font-size: 12px; }
#behoo .tag.routed { background: var(--soft); color: var(--accent); }
#behoo .tag.success { background: var(--green-soft); color: var(--green); }
#behoo .table-note { margin-top: 6px; }
#behoo .field { display: grid; gap: 7px; }
#behoo .field > span { font-weight: 650; }
#behoo input, #behoo select { width: 100%; min-width: 0; border: 1px solid var(--line); min-height: 38px; padding: 8px 10px; border-radius: 8px; background: var(--surface); color: var(--ink); }
#behoo input[type="checkbox"] { width: 17px; height: 17px; min-height: 0; accent-color: var(--blue); }
#behoo table select { width: auto; min-height: 33px; padding-block: 4px; font-size: 13px; }
#behoo .wizard-track { list-style: none; display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 8px; margin: 0; padding: 0; }
#behoo .wizard-track button { width: 100%; display: flex; align-items: center; gap: 8px; padding: 9px 10px; text-align: start; border: 1px solid var(--line); border-radius: 10px; background: var(--panel); color: var(--muted); font-size: 13px; }
#behoo .wizard-track button[aria-current] { color: var(--accent); border-color: var(--accent); background: var(--soft); font-weight: 700; }
#behoo .step-index { border-radius: 50%; display: grid; place-items: center; width: 22px; height: 22px; flex: none; background: var(--surface); font-size: 12px; }
#behoo [aria-current] .step-index { background: var(--panel); }
#behoo .choices { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
#behoo .choice { width: 100%; display: grid; gap: 5px; padding: 15px; text-align: start; border: 1px solid var(--line); border-radius: 11px; background: var(--surface); color: var(--ink); min-width: 0; overflow-wrap: anywhere; }
#behoo .choice[aria-pressed="true"] { background: var(--soft); border-color: var(--accent); color: var(--accent); }
#behoo .choice strong { font-size: 14px; }
#behoo .wizard-footer { display: flex; justify-content: space-between; gap: 10px; }
#behoo .line-list { display: grid; gap: 8px; }
#behoo .line-option { display: flex; align-items: center; gap: 9px; text-align: start; width: 100%; color: var(--ink); background: var(--surface); border: 1px solid var(--line); border-radius: 9px; padding: 10px 11px; }
#behoo .line-option[aria-pressed="true"] { border-color: var(--accent); color: var(--accent); background: var(--soft); }
#behoo .line-option .micro { margin-left: auto; }
#behoo .meter { background: var(--surface); height: 7px; border-radius: 6px; overflow: hidden; }
#behoo .meter > span { display: block; height: 100%; background: var(--blue); border-radius: inherit; }
#behoo .subscription { display: grid; gap: 13px; }
#behoo .search { width: min(220px, 100%); }
#behoo .setting-row { min-height: 52px; display: grid; grid-template-columns: minmax(0, 1fr) minmax(118px, 175px); align-items: center; gap: 12px; border-top: 1px solid var(--line); }
#behoo .setting-row:first-of-type { margin-top: 12px; }
#behoo .setting-row label { font-weight: 600; }
#behoo .setting-row input[type="checkbox"] { justify-self: end; }
#behoo .dialog { width: min(460px, calc(100vw - 28px)); border: 1px solid var(--line); border-radius: 17px; padding: 22px; color: var(--ink); background: var(--panel); box-shadow: 0 18px 60px #1427444a; }
#behoo .dialog::backdrop { background: #182b4673; }
#behoo .dialog form { display: grid; gap: 14px; }
#behoo .dialog .actions { margin-top: 3px; }
#behoo .error { color: var(--red); font-size: 13px; }
#behoo .toast { position: fixed; right: 20px; bottom: 19px; z-index: 2; max-width: calc(100vw - 40px); padding: 10px 15px; border-radius: 10px; color: var(--ink); background: var(--panel); border: 1px solid var(--line); box-shadow: 0 7px 30px #15274124; }
@media (max-width: 560px) {
  #behoo .overview-grid { grid-template-columns: minmax(0, 1fr); }
  #behoo .plugin-header { padding-inline: 12px; }
  #behoo main { padding-inline: 12px; }
  #behoo .hero { padding: 19px 16px; min-height: 180px; grid-template-columns: minmax(0, 1fr) 85px; gap: 8px; }
  #behoo .power { width: 57px; height: 57px; }
  #behoo .power .icon { width: 25px; height: 25px; }
  #behoo .power-area { gap: 7px; }
  #behoo .hero-summary { gap: 6px 10px; }
  #behoo .panel-pad { padding: 15px 16px; }
  #behoo .page-header { flex-wrap: wrap; margin-bottom: 15px; }
  #behoo .wizard-track { gap: 5px; }
  #behoo .wizard-track button { gap: 4px; padding: 7px 4px; font-size: 10px; }
  #behoo .step-index { width: 16px; height: 16px; font-size: 10px; }
}
@media (prefers-reduced-motion: reduce) {
  #behoo *, #behoo *::before, #behoo *::after { transition: none !important; }
}
</style>
</head>
<body class="bg" skin='<% nvram_get("sc_skin"); %>'>
<div id="TopBanner"></div>
<div id="Loading" class="popup_bg"></div>
<table class="content" align="center" cellpadding="0" cellspacing="0">
  <tbody><tr>
    <td width="17"></td>
    <td valign="top" width="202"><div id="mainMenu"></div><div id="subMenu"></div></td>
    <td valign="top">
      <div id="tabMenu" class="submenuBlock"></div>
      <div id="behoo" data-theme="dark">
<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" aria-hidden="true" style="position:absolute">
  <symbol id="i-overview" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="4"/><path d="M6 14h3l2-5 3 7 2-4h2"/></symbol>
  <symbol id="i-route" viewBox="0 0 24 24"><path d="M4 7h16m-4-4 4 4-4 4M20 17H4m4-4-4 4 4 4"/></symbol>
  <symbol id="i-sub" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 10h10m-10 4h5"/></symbol>
  <symbol id="i-device" viewBox="0 0 24 24"><rect x="2.5" y="4" width="15" height="12" rx="2"/><path d="M7 20h6m-3-4v4"/><rect x="15" y="9" width="6.5" height="11" rx="1.5"/></symbol>
  <symbol id="i-links" viewBox="0 0 24 24"><path d="M3 15h6l3-8 3 11 2-5h4"/></symbol>
  <symbol id="i-settings" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/><circle cx="8" cy="6" r="2" fill="var(--panel)"/><circle cx="15" cy="12" r="2" fill="var(--panel)"/><circle cx="9" cy="18" r="2" fill="var(--panel)"/></symbol>
  <symbol id="i-router" viewBox="0 0 24 24"><rect x="3" y="12" width="18" height="8" rx="2"/><path d="M6 12V5m12 7V5M7 16h1m3 0h1"/></symbol>
  <symbol id="i-power" viewBox="0 0 24 24"><path d="M12 2v10m4.6-6.2a8.3 8.3 0 1 1-9.2 0"/></symbol>
  <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
  <symbol id="i-moon" viewBox="0 0 24 24"><path d="M20 15.3A8.8 8.8 0 0 1 8.7 4 8.8 8.8 0 1 0 20 15.3Z"/></symbol>
  <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4 19 5"/></symbol>
  <symbol id="i-chevron" viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></symbol>
</svg>
<header class="plugin-header">
  <div class="row">
    <div class="brand">
      <img src="/res/icon-behoo.png" alt="" width="36" height="36">
      <div><strong>壁虎 Behoo</strong><a id="software-center-link" class="micro" href="/Module_Softcenter.asp">返回软件中心</a></div>
    </div>
    <div class="actions">
      <span class="status-tag" id="platform" aria-live="polite">连接中</span>
      <button id="theme" class="button icon-button" aria-label="切换浅色外观"><svg class="icon small"><use href="#i-sun"/></svg></button>
      <button class="button primary" data-add><svg class="icon small"><use href="#i-plus"/></svg>添加订阅</button>
    </div>
  </div>
    <nav class="plugin-tabs" aria-label="壁虎功能">
      <button data-page="overview" aria-current="page"><svg class="icon"><use href="#i-overview"/></svg>连接概览</button>
      <button data-page="routing"><svg class="icon"><use href="#i-route"/></svg>线路配置</button>
      <button data-page="subscriptions"><svg class="icon"><use href="#i-sub"/></svg>我的订阅</button>
      <button data-page="devices"><svg class="icon"><use href="#i-device"/></svg>局域网设备</button>
      <button data-page="connections"><svg class="icon"><use href="#i-links"/></svg>当前连接</button>
      <button data-page="settings"><svg class="icon"><use href="#i-settings"/></svg>插件设置</button>
    </nav>
</header>
  <main>
    <header class="page-header">
      <h1 id="page-title" tabindex="-1">连接概览</h1>
      <p class="micro">局域网网关 <span class="mono" id="gateway">—</span></p>
    </header>
    <section class="stack" data-view="overview" aria-labelledby="page-title">
      <section class="panel hero" aria-label="代理开关">
        <div class="hero-copy">
          <div class="hero-kicker"><svg class="icon small"><use href="#i-router"/></svg>Mihomo 内核</div>
          <h2 class="state" id="connection-state" role="status">读取状态…</h2>
          <p class="muted hero-note" id="connection-note"></p>
          <dl class="hero-summary">
            <div><dt>工作方式</dt><dd id="active-inbound"></dd></div>
            <div><dt>网络模式</dt><dd id="active-mode"></dd></div>
          </dl>
        </div>
        <div class="power-area">
          <button class="power" id="power" disabled aria-pressed="false" aria-label="连接代理"><svg class="icon"><use href="#i-power"/></svg></button>
          <span class="power-caption" id="power-caption" aria-hidden="true">连接代理</span>
        </div>
      </section>
      <div class="overview-grid">
        <section class="panel panel-pad traffic" aria-labelledby="traffic-title">
          <div class="section-heading"><h2 id="traffic-title">实时流量</h2><span class="micro">最近 60 秒</span></div>
          <div class="traffic-values">
            <div class="traffic-value"><span><i class="dot down"></i>下载</span><strong id="traffic-down">—</strong></div>
            <div class="traffic-value"><span><i class="dot up"></i>上传</span><strong id="traffic-up">—</strong></div>
          </div>
          <canvas id="chart" role="img" aria-label="最近 60 秒的上传和下载速率"></canvas>
          <div class="chart-axis" aria-hidden="true"><span>60 秒前</span><span>30 秒前</span><span>现在</span></div>
        </section>
        <section class="panel panel-pad profile-summary" aria-labelledby="profile-title">
          <div class="section-heading"><h2 id="profile-title">当前线路</h2><button class="button text" data-go="routing">配置线路<svg class="icon small"><use href="#i-chevron"/></svg></button></div>
          <dl class="summary-list">
            <div><dt>使用订阅</dt><dd id="summary-profile"></dd></div>
            <div><dt>选线方式</dt><dd id="summary-driving"></dd></div>
            <div><dt id="exit-label">当前默认出口</dt><dd id="summary-exit"></dd></div>
          </dl>
        </section>
      </div>
      <section class="panel panel-pad" aria-labelledby="overview-devices">
        <div class="section-heading"><h2 id="overview-devices">局域网设备</h2><button class="button text" data-go="devices">管理设备<svg class="icon small"><use href="#i-chevron"/></svg></button></div>
        <div class="table-wrap"><table><thead><tr><th scope="col">设备</th><th scope="col">局域网 IP</th><th scope="col">设备策略</th></tr></thead><tbody id="overview-device-list"></tbody></table></div>
      </section>
    </section>
    <section data-view="routing" class="stack" aria-labelledby="page-title" hidden>
      <ol class="wizard-track" aria-label="配置进度" id="wizard-track"></ol>
      <div class="panel panel-pad stack" id="wizard-body"></div>
      <footer class="wizard-footer"><button class="button" id="wizard-back">上一步</button><button class="button primary" id="wizard-next">下一步</button></footer>
    </section>
    <section data-view="subscriptions" class="stack" id="subscriptions" aria-labelledby="page-title" hidden></section>
    <section data-view="devices" class="stack" aria-labelledby="page-title" hidden>
      <section class="panel panel-pad">
        <div class="section-heading">
          <div><h2>设备接管策略</h2><p class="muted table-note">新设备默认直连。更改设备策略后，点击应用保存。</p></div>
          <div class="actions"><button class="button" id="add-device">添加设备</button><button class="button primary" id="save-devices" disabled>应用策略</button></div>
        </div>
        <div class="table-wrap"><table><thead><tr><th scope="col">设备</th><th scope="col">局域网 IP</th><th scope="col">MAC 地址</th><th scope="col">设备策略</th></tr></thead><tbody id="device-list"></tbody></table></div>
      </section>
    </section>
    <section data-view="connections" class="stack" aria-labelledby="page-title" hidden>
      <section class="panel panel-pad">
        <div class="section-heading"><h2 id="connection-count" aria-live="polite">活跃连接</h2><input class="search" id="connection-search" type="search" aria-label="搜索连接" placeholder="搜索目标、设备或线路"></div>
        <div class="table-wrap"><table id="connection-table"><thead><tr><th scope="col">目标</th><th scope="col">来源设备</th><th scope="col">出口</th><th scope="col">下载</th></tr></thead><tbody id="connection-list"></tbody></table></div>
        <p id="empty-connections" class="muted table-note" hidden></p>
      </section>
    </section>
    <section data-view="settings" class="stack" aria-labelledby="page-title" hidden>
      <form id="settings-form" class="stack">
        <section class="panel panel-pad">
          <h2>工作方式</h2>
          <div class="setting-row"><label for="inbound">接管方式</label><select id="inbound" name="inbound"><option value="transparent">透明代理</option><option value="manual">HTTP / SOCKS5</option></select></div>
          <p class="muted" id="inbound-hint"></p>
          <div class="setting-row"><label for="autostart">路由器开机启动</label><input id="autostart" name="autostart" type="checkbox"></div>
        </section>
        <section class="panel panel-pad">
          <h2>订阅更新</h2>
          <div class="setting-row"><label for="interval">更新频率</label><select id="interval" name="interval"><option value="subscription">按订阅建议</option><option value="manual">仅手动</option><option value="24">每 24 小时</option></select></div>
          <div class="setting-row"><label for="update-network">更新网络</label><select id="update-network" name="network"><option value="subscription">按订阅建议</option><option value="direct">优先直连</option><option value="proxy">优先代理</option></select></div>
          <p class="muted">首选网络失败时尝试另一条路径。更新失败时继续使用上次可用配置。</p>
        </section>
        <div class="actions"><button class="button primary">保存设置</button></div>
      </form>
    </section>
  </main>
<dialog class="dialog" id="add-dialog" aria-labelledby="add-title">
  <form id="subscription-form" novalidate>
    <h2 id="add-title">添加订阅</h2>
    <label class="field"><span>显示名称</span><input name="name" maxlength="40" placeholder="我的订阅" autocomplete="off"></label>
    <label class="field"><span>订阅地址</span><input id="import-url" name="url" type="url" required placeholder="https://example.com/subscription" autocomplete="off" spellcheck="false" aria-describedby="import-error"></label>
    <p class="muted" id="import-progress" role="status" hidden></p>
    <p class="error" id="import-error" role="alert" hidden></p>
    <div class="actions"><button id="import-cancel" type="button" class="button" data-close="add-dialog">取消</button><button id="import-submit" type="submit" class="button primary">导入订阅</button></div>
  </form>
</dialog>
<dialog class="dialog" id="device-dialog" aria-labelledby="device-title">
  <form id="device-form">
    <h2 id="device-title">添加设备</h2>
    <label class="field"><span>MAC 地址</span><input name="mac" required pattern="([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}" placeholder="02:00:00:00:00:03"></label>
    <div class="actions"><button type="button" class="button" data-close="device-dialog">取消</button><button class="button primary">加入接管列表</button></div>
  </form>
</dialog>
<p class="toast" id="toast" role="status" hidden></p>
      </div>
    </td>
  </tr></tbody>
</table>
<div id="footer"></div>
<script>
(() => {
"use strict";

const root = document.getElementById("behoo");
const get = (id) => root.querySelector("#" + id);
const views = Array.from(root.querySelectorAll("[data-view]"));
const navigation = Array.from(root.querySelectorAll(".plugin-tabs [data-page]"));
const icon = (name) => '<svg class="icon small" aria-hidden="true"><use href="#i-' + name + '"/></svg>';
const escapeText = (value) => String(value).replace(/[&<>"']/g, (character) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
})[character]);

const inboundNames = { transparent: "透明代理", manual: "HTTP / SOCKS5" };
const networkModes = { rule: "规则", global: "全局" };
const drivingModes = { auto: "全自动驾驶", manual: "手动驾驶" };
const policyNames = { proxy: "通过代理", direct: "直连" };
const stepNames = ["选订阅", "网络模式", "网络出口", "确认配置"];


const data = { profiles: [], devices: [], connections: [], traffic: [], token: "", gateway: "", exit: "", problem: "", mode: "" };
const state = {
  page: "overview", connected: false, changing: false, available: false, step: 0,
  plan: { profile: "", mode: "rule", driving: "auto", line: "" },
  settings: { inbound: "transparent", autostart: false, interval: "subscription", network: "subscription" },
  deviceDraft: {}, wizard: null
};
let toastTimer;
let apiPath = "/_api/";

function currentProfile(id) {
  return data.profiles.find((profile) => profile.id === id);
}

function exitFor(plan) {
  if (plan.driving === "manual") return plan.line || "请选择出口";
  return data.exit && plan.profile === state.plan.profile && state.plan.driving === "auto" ? data.exit : "自动选择";
}

function bytes(value) {
  const count = Number(value) || 0;
  if (count >= 1e9) return (count / 1e9).toFixed(1) + " GB";
  if (count >= 1e6) return (count / 1e6).toFixed(2) + " MB";
  if (count >= 1e3) return (count / 1e3).toFixed(0) + " KB";
  return count + " B";
}

function encodedRequest(object) {
  const bytes = new TextEncoder().encode(JSON.stringify(object));
  return btoa(Array.from(bytes, (number) => String.fromCharCode(number)).join(""))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function transientRPCError(message) {
  return Object.assign(new Error(message), { temporary: true });
}

async function fetchRPCEnvelope(path, options, wait) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), wait);
  try {
    const response = await fetch(path, { ...options, signal: controller.signal });
    if (!response.ok) return { status: response.status };
    const envelope = await response.json().catch(() => {
      throw new Error("软件中心接口未返回 JSON。请确认仍处于已登录的软件中心页面。");
    });
    return { status: response.status, envelope };
  } catch (error) {
    if (controller.signal.aborted) throw transientRPCError("等待软件中心接口响应超时。");
    if (error instanceof TypeError) throw transientRPCError("无法连接软件中心接口 " + path + "。");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

async function rpc(action, fields = {}) {
  const id = Math.floor(Math.random() * 90000000) + 10000000;
  const common = { cache: "no-store", credentials: "same-origin" };
  const options = {
    ...common, method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "X-Requested-With": "XMLHttpRequest"
    },
    body: JSON.stringify({
      id, method: "behoo_rpc.sh",
      params: [encodedRequest({ action, token: data.token, ...fields })], fields: {}
    })
  };
  let path = apiPath;
  let reply;
  try {
    reply = await fetchRPCEnvelope(path, options, 12000);
    // Only probe alternate routes with a read-only status request.
    if (action === "status" && [404, 405].includes(reply.status)) {
      path = path === "/_api/" ? "/_api" : "/_api/";
      reply = await fetchRPCEnvelope(path, options, 12000);
    }
    if (reply.status === 408 || reply.status >= 500) {
      throw transientRPCError("软件中心接口 " + path + " 返回 HTTP " + reply.status + "。");
    }
  } catch (error) {
    if (!error.temporary) throw error;
    // Some software-center versions keep the response after the POST times out.
    const saved = await fetchRPCEnvelope("/_result/" + id, common, 3000).catch(() => null);
    if (typeof saved?.envelope?.result !== "string" || !/^[A-Za-z0-9_-]{8,}$/.test(saved.envelope.result)) {
      throw error;
    }
    reply = saved;
  }
  if (reply.status < 200 || reply.status >= 300) {
    throw new Error("软件中心接口 " + path + " 返回 HTTP " + reply.status + "。");
  }
  const result = reply.envelope?.result;
  if (typeof result !== "string" || !/^[A-Za-z0-9_-]{8,}$/.test(result)) {
    throw new Error("壁虎服务未响应，请检查软件中心安装状态。");
  }
  const decoded = Uint8Array.from(atob(result.replace(/-/g, "+").replace(/_/g, "/")), (character) => character.charCodeAt(0));
  const output = JSON.parse(new TextDecoder().decode(decoded));
  if (action === "status") apiPath = path;
  if (output.error) throw Object.assign(new Error(output.error), { code: output.code });
  return output.data;
}

async function syncStatus(draw = true) {
  const result = await rpc("status");
  for (const key of ["token", "gateway", "exit", "problem", "mode"]) data[key] = result[key] || "";
  data.profiles = result.profiles;
  state.plan = { profile: "", mode: "rule", driving: "auto", line: "", ...result.plan };
  state.plan.mode ||= "rule";
  state.plan.driving ||= "auto";
  state.settings = result.settings;
  state.connected = result.connected;
  state.available = true;
  get("gateway").textContent = data.gateway || "—";
  get("platform").textContent = data.mode === "tproxy" ? "IPv4 TCP / UDP" : data.mode === "redirect" ? "IPv4 仅 TCP" :
    data.mode === "manual" ? "HTTP / SOCKS5" : "服务就绪";
  if (draw) render();
}

let changingJob = false;
async function action(name, fields, onSuccess, onError = tell) {
  if (changingJob) {
    onError("有操作正在执行，请稍后重试。");
    return false;
  }
  changingJob = true;
  let stage = "连接壁虎服务";
  try {
    if (!state.available) await syncStatus(false);
    stage = name === "import" ? "提交订阅导入" : "提交操作";
    const operation = name === "import"
      ? Array.from(crypto.getRandomValues(new Uint8Array(16)), (number) => number.toString(16).padStart(2, "0")).join("")
      : "";
    let jobID = operation;
    let awaitingReceipt = false;
    try {
      const job = await rpc(name, operation ? { ...fields, operation } : fields);
      jobID = job.id;
    } catch (error) {
      if (!operation || !error.temporary) throw error;
      awaitingReceipt = true;
    }
    stage = name === "import" ? "查询订阅导入结果" : "查询操作结果";
    const deadline = Date.now() + 150000;
    let failedPolls = 0;
    for (;;) {
      await new Promise((resolve) => setTimeout(resolve, 650));
      if (Date.now() >= deadline) throw new Error("等待任务结束超时，请刷新状态。");
      let result;
      try {
        result = await rpc("job", { id: jobID });
      } catch (error) {
        const notReceived = awaitingReceipt && error.code === "job_not_found";
        if ((error.temporary || notReceived) && ++failedPolls < 3) continue;
        if (notReceived) throw new Error("提交回执超时，路由器未确认收到这笔导入。");
        throw error;
      }
      awaitingReceipt = false;
      failedPolls = 0;
      if (!result.done) continue;
      stage = "";
      if (result.error) throw new Error(result.error);
      break;
    }
    try {
      await syncStatus(false);
    } catch (error) {
      state.available = false;
      throw new Error("操作已完成，但无法刷新插件状态。" + error.message);
    }
    if (onSuccess) await onSuccess();
    render();
    return true;
  } catch (error) {
    onError((stage ? stage + "失败。" : "") + error.message);
    return false;
  } finally {
    changingJob = false;
  }
}
function tell(message) {
  get("toast").textContent = message;
  get("toast").hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { get("toast").hidden = true; }, 3300);
}

function go(page, focus = true) {
  const button = navigation.find((item) => item.dataset.page === page);
  if (!button) return;
  if (page === "routing" && state.page !== "routing") {
    state.wizard = { ...state.plan };
    state.step = 0;
  }
  state.page = page;
  navigation.forEach((item) => {
    if (item === button) item.setAttribute("aria-current", "page");
    else item.removeAttribute("aria-current");
  });
  views.forEach((view) => { view.hidden = view.dataset.view !== page; });
  get("page-title").textContent = button.textContent.trim();
  render();
  if (state.available && ["overview", "devices", "connections"].includes(page)) {
    refreshLive(page).catch((error) => tell(error.message));
  }
  if (focus) {
    get("page-title").focus({ preventScroll: true });
    root.scrollIntoView({ block: "nearest" });
  }
}

function render() {
  switch (state.page) {
    case "overview": renderOverview(); break;
    case "routing": renderWizard(); break;
    case "subscriptions": renderSubscriptions(); break;
    case "devices": renderDevices(); break;
    case "connections": renderConnections(); break;
    case "settings": renderSettings(); break;
  }
}

function renderOverview() {
  const { connected, changing, settings, plan } = state;
  const managed = data.devices.filter((device) => device.policy === "proxy").length;
  const status = get("connection-state");
  status.textContent = !state.available ? "服务不可用" : changing ? (connected ? "正在断开…" : "正在连接…") : (connected ? "已连接" : "未连接");
  status.classList.toggle("connected", connected && !changing);
  const note = data.problem || (connected ? (settings.inbound === "transparent" ?
    managed + " 台局域网设备已接管" : "手动代理入口 " + data.gateway + ":17990") :
    (data.profiles.length ? "局域网设备当前直连" : "请先添加订阅。"));
  get("connection-note").textContent = note;
  get("active-inbound").textContent = inboundNames[settings.inbound];
  get("active-mode").textContent = networkModes[plan.mode];
  const powerLabel = connected ? "断开代理" : "连接代理";
  get("power").setAttribute("aria-pressed", String(connected));
  get("power").setAttribute("aria-label", powerLabel);
  get("power").disabled = changing || !state.available || (!connected && !data.profiles.length);
  get("power-caption").textContent = powerLabel;
  get("summary-profile").textContent = currentProfile(plan.profile)?.name ?? "—";
  get("summary-driving").textContent = drivingModes[plan.driving];
  get("exit-label").textContent = connected ? "当前默认出口" : "配置默认出口";
  get("summary-exit").textContent = exitFor(plan);
  get("overview-device-list").innerHTML = data.devices.map((device) => {
    const applied = connected && settings.inbound === "transparent" ? device.policy : "direct";
    const label = settings.inbound === "manual" && connected ? "手动配置" : policyNames[applied];
    return '<tr><td>' + deviceName(device) + '</td><td class="mono">' + escapeText(device.ip || "—") +
      '</td><td><span class="tag ' + (applied === "proxy" ? "routed" : "") + '">' + label + '</span></td></tr>';
  }).join("");
  drawChart();
}

function drawChart() {
  const canvas = get("chart");
  const bounds = canvas.getBoundingClientRect();
  if (!bounds.width) return;
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const width = bounds.width;
  const height = bounds.height;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  const context = canvas.getContext("2d");
  context.scale(ratio, ratio);
  const colors = getComputedStyle(root);
  const history = state.connected ? data.traffic : [];
  const empty = { down: 0, up: 0 };
  const series = Array.from({ length: 60 }, (_, i) => history[i - (60 - history.length)] ?? empty);
  const latest = series.at(-1);
  const max = Math.max(1e3, ...series.flatMap((sample) => [sample.up, sample.down]));
  get("traffic-down").textContent = bytes(latest.down) + "/s";
  get("traffic-up").textContent = bytes(latest.up) + "/s";
  context.strokeStyle = colors.getPropertyValue("--line").trim();
  for (let y = 7; y < height; y += (height - 8) / 3) {
    context.beginPath();
    context.moveTo(0, y);
    context.lineTo(width, y);
    context.stroke();
  }
  for (const metric of ["down", "up"]) {
    const color = colors.getPropertyValue("--chart-" + metric).trim();
    const points = series.map((value, i) => [i * width / (series.length - 1), height - 3 - (height - 10) * value[metric] / max]);
    context.beginPath();
    points.forEach(([x, y], i) => i ? context.lineTo(x, y) : context.moveTo(x, y));
    context.strokeStyle = color;
    context.lineWidth = 1.8;
    context.lineJoin = "round";
    context.stroke();
    if (metric === "down" && state.connected) {
      context.lineTo(width, height);
      context.lineTo(0, height);
      context.closePath();
      const gradient = context.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, color + "36");
      gradient.addColorStop(1, color + "05");
      context.fillStyle = gradient;
      context.fill();
    }
  }
}

function deviceName(device) {
  return '<span class="device-name">' + icon("device") + escapeText(device.name) + "</span>";
}

function renderDevices() {
  get("device-list").innerHTML = data.devices.map((device) => {
    const selected = state.deviceDraft[device.id] ?? device.policy;
    const choices = Object.entries(policyNames).map(([value, label]) =>
      '<option value="' + value + '"' + (selected === value ? " selected" : "") + ">" + label + "</option>").join("");
    return "<tr><td>" + deviceName(device) + '</td><td class="mono">' + escapeText(device.ip || "—") + '</td><td class="mono">' +
      device.mac + '</td><td><select aria-label="' + escapeText(device.name) + ' 的设备策略" data-device="' +
      device.id + '">' + choices + "</select></td></tr>";
  }).join("");
  get("save-devices").disabled = !Object.keys(state.deviceDraft).length;
}

function renderConnections() {
  const query = get("connection-search").value.trim().toLowerCase();
  const active = state.connected ? data.connections : [];
  const visible = active.flatMap((connection) => {
    const fields = [connection.host, connection.source, connection.exit];
    if (!fields.some((value) => value.toLowerCase().includes(query))) return [];
    return ['<tr><td>' + escapeText(connection.host) + "</td><td>" + escapeText(connection.source) +
      "</td><td>" + escapeText(connection.exit || "—") + "</td><td>" + bytes(connection.download) + "</td></tr>"];
  });
  get("connection-count").textContent = active.length + " 条活跃连接";
  get("connection-list").innerHTML = visible.join("");
  get("connection-table").hidden = !visible.length;
  get("empty-connections").hidden = Boolean(visible.length);
  get("empty-connections").textContent = active.length ? "没有匹配的连接。" : "暂无活跃连接。";
}

function choice(group, value, selected, title, detail) {
  return '<button type="button" class="choice" data-choice="' + group + '" value="' + escapeText(value) +
    '" aria-pressed="' + (selected === value) + '"><strong>' + escapeText(title) + '</strong><span class="muted">' +
    escapeText(detail) + "</span></button>";
}

function wizardContent(wizard) {
  const profile = currentProfile(wizard.profile);
  if (!profile && state.step > 0) return "<p>请先添加并选择订阅。</p>";
  switch (state.step) {
    case 0:
      return '<div class="section-heading"><h2>选订阅</h2><button class="button text" data-add>添加订阅</button></div><div class="choices">' +
        data.profiles.map((item) => choice("profile", item.id, wizard.profile, item.name, item.format)).join("") + "</div>";
    case 1:
      return '<h2>选网络模式</h2><div class="choices">' +
        choice("mode", "rule", wizard.mode, "规则", "按订阅规则决定哪些流量走代理。") +
        choice("mode", "global", wizard.mode, "全局", "已接管设备的流量使用所选代理出口。") + "</div>";
    case 2: {
      const manual = wizard.driving === "manual";
      const options = profile.lines.map(({ name }) =>
        '<button class="line-option" type="button" data-choice="line" value="' + escapeText(name) +
        '" aria-pressed="' + (wizard.line === name) + '">' + icon("route") + escapeText(name) + "</button>").join("");
      const autoDetail = wizard.mode === "rule" ? "保留订阅场景，自动选择默认出口。" : "从可用线路中自动选择默认出口。";
      return '<h2>选网络出口</h2><div class="choices">' +
        choice("driving", "manual", wizard.driving, "手动驾驶", "自己选择默认出口。") +
        choice("driving", "auto", wizard.driving, "全自动驾驶", autoDetail) +
        '</div>' + (manual ? '<div class="line-list">' + options + '</div>' : '<p class="muted">自动出口 · ' +
          escapeText(exitFor(wizard)) + "</p>");
    }
    case 3:
      return '<h2>确认配置</h2><dl class="detail-list"><div><dt>订阅</dt><dd>' +
        escapeText(profile.name) + "</dd></div><div><dt>网络模式</dt><dd>" + networkModes[wizard.mode] +
        "</dd></div><div><dt>选线方式</dt><dd>" + drivingModes[wizard.driving] +
        "</dd></div><div><dt>默认出口</dt><dd>" + escapeText(exitFor(wizard)) + "</dd></div></dl>";
  }
}

function renderWizard() {
  get("wizard-track").innerHTML = stepNames.map((label, i) =>
    '<li><button type="button" data-step="' + i + '"' + (i === state.step ? ' aria-current="step"' : "") +
    '><span class="step-index">' + (i + 1) + "</span>" + label + "</button></li>").join("");
  get("wizard-body").innerHTML = wizardContent(state.wizard);
  get("wizard-back").disabled = state.step === 0;
  get("wizard-next").disabled = !currentProfile(state.wizard.profile) || (state.step >= 2 && state.wizard.driving === "manual" && !state.wizard.line);
  get("wizard-next").textContent = state.step === 3 ? "应用配置" : "下一步";
}

function renderSubscriptions() {
  if (!data.profiles.length) {
    get("subscriptions").innerHTML = '<p class="panel panel-pad muted">可添加壁虎 JSON v1 或 Clash YAML 订阅。</p>';
    return;
  }
  get("subscriptions").innerHTML = data.profiles.map((profile) => {
    const active = state.plan.profile === profile.id;
    const used = profile.used ?? 0;
    const total = used + (profile.remaining ?? 0);
    const quota = total ? '<div class="meter" role="meter" aria-label="订阅已用流量" aria-valuemin="0" aria-valuemax="' +
      total + '" aria-valuenow="' + used + '"><span style="width:' + (100 * used / total) +
      '%"></span></div><p class="muted">已用 ' + bytes(used) + ' / ' + bytes(total) + '</p>' : "";
    return '<article class="panel panel-pad subscription"><header class="section-heading"><div><h2>' +
      escapeText(profile.name) + '</h2><p class="micro">' + profile.format + '</p></div>' +
      (active ? '<span class="tag success"><i class="dot green"></i>当前订阅</span>' :
        '<button class="button text" data-pick="' + profile.id + '">配置线路</button>') + '</header>' + quota +
      '<div class="section-heading"><p class="muted">' + (profile.expiry ? "到期 " + escapeText(profile.expiry) + " · " : "") +
      "更新 " + (profile.updated ? new Date(profile.updated * 1000).toLocaleString() : "—") +
      (profile.interval ? " · 订阅建议每 " + profile.interval + " 小时" : "") +
      (profile.status ? " · " + escapeText(profile.status) : "") +
      '</p><div class="actions"><button class="button" data-refresh="' + profile.id +
      '">更新订阅</button><button class="button danger" data-remove="' + profile.id + '"' +
      (active && state.connected ? ' disabled title="断开连接后可删除当前订阅"' : "") + '>移除</button></div></div></article>';
  }).join("");
}

function renderInboundHint() {
  get("inbound-hint").textContent = get("inbound").value === "transparent" ?
    "按局域网设备策略接管流量，选中的设备无需单独设置代理。" :
    ("设备自行将代理地址设为 " + (data.gateway || "路由器 IPv4 地址") + ":17990。");
}

function renderSettings() {
  const fields = get("settings-form").elements;
  for (const key of ["inbound", "interval", "network"]) fields.namedItem(key).value = state.settings[key];
  fields.namedItem("autostart").checked = state.settings.autostart;
  renderInboundHint();
}

function choose(button) {
  const { choice: key } = button.dataset;
  state.wizard[key] = button.value;
  if (key === "profile") state.wizard.line = currentProfile(button.value).lines[0]?.name ?? "";
  renderWizard();
  Array.from(get("wizard-body").querySelectorAll("[data-choice]")).find((item) =>
    item.dataset.choice === key && item.value === button.value)?.focus();
}

root.addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  const target = button.dataset;
  if (target.page || target.go) go(target.page || target.go);
  if ("add" in target) get("add-dialog").showModal();
  if (target.close) get(target.close).close();
  if (target.choice) choose(button);
  if (target.step !== undefined) {
    state.step = Number(target.step);
    renderWizard();
    get("wizard-track").querySelector("[aria-current]").focus();
  }
  if (target.pick) {
    go("routing");
    state.wizard.profile = target.pick;
    state.wizard.line = currentProfile(target.pick).lines[0]?.name ?? "";
    renderWizard();
  }
  if (target.refresh) action("refresh", { id: target.refresh }, () => tell("订阅已更新。"));
  if (target.remove && confirm("移除该订阅？")) action("remove", { id: target.remove }, () => tell("订阅已移除。"));
});

get("wizard-back").addEventListener("click", () => {
  state.step--;
  renderWizard();
  if (!state.step) get("wizard-next").focus();
});
get("wizard-next").addEventListener("click", () => {
  if (state.step < stepNames.length - 1) {
    state.step++;
    renderWizard();
    return;
  }
  action("plan", { plan: state.wizard }, () => {
    go("overview");
    tell("线路配置已应用。");
  });
});

get("power").addEventListener("click", async () => {
  state.changing = true;
  renderOverview();
  await action("power", { enabled: !state.connected }, () => { if (!state.connected) data.traffic = []; });
  state.changing = false;
  render();
  get("power").focus();
});
get("device-list").addEventListener("change", (event) => {
  const { device: id } = event.target.dataset;
  if (!id) return;
  const policy = event.target.value;
  if (data.devices.find((device) => device.id === id).policy === policy) delete state.deviceDraft[id];
  else state.deviceDraft[id] = policy;
  get("save-devices").disabled = !Object.keys(state.deviceDraft).length;
});
get("save-devices").addEventListener("click", () => {
  action("policies", { devices: state.deviceDraft }, async () => {
    state.deviceDraft = {};
    await refreshLive("devices");
    tell("设备策略已应用。");
  });
});
get("add-device").addEventListener("click", () => get("device-dialog").showModal());
get("device-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const mac = new FormData(event.currentTarget).get("mac").toLowerCase();
  await action("policies", { devices: { [mac]: "proxy" } }, async () => {
    get("device-dialog").close();
    get("device-form").reset();
    await refreshLive("devices");
    tell("设备已加入接管列表。");
  });
});
get("connection-search").addEventListener("input", renderConnections);

get("inbound").addEventListener("change", renderInboundHint);
get("settings-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const values = new FormData(event.currentTarget);
  const settings = {
    inbound: values.get("inbound"),
    autostart: values.has("autostart"),
    interval: values.get("interval"),
    network: values.get("network")
  };
  action("settings", { settings }, () => tell("设置已保存。"));
});
get("theme").addEventListener("click", () => {
  const dark = root.dataset.theme !== "dark";
  root.dataset.theme = dark ? "dark" : "light";
  get("theme").setAttribute("aria-label", dark ? "切换浅色外观" : "切换暗色外观");
  get("theme").innerHTML = icon(dark ? "sun" : "moon");
  if (state.page === "overview") drawChart();
});


get("subscription-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const dialog = get("add-dialog");
  const submit = get("import-submit");
  const cancel = get("import-cancel");
  const progress = get("import-progress");
  const error = get("import-error");
  const urlInput = get("import-url");
  if (submit.disabled) return;
  error.hidden = true;
  urlInput.removeAttribute("aria-invalid");
  const showError = (message) => {
    error.textContent = message;
    error.hidden = false;
    if (!dialog.open) tell(message);
  };
  const values = new FormData(form);
  const url = values.get("url").trim();
  let protocol;
  try { protocol = new URL(url).protocol; } catch {}
  if (!["http:", "https:", "bihu:", "clash:"].includes(protocol)) {
    urlInput.setAttribute("aria-invalid", "true");
    showError("请输入有效的订阅地址或壁虎、Clash 导入链接。");
    urlInput.focus();
    return;
  }
  submit.disabled = true;
  submit.textContent = "正在导入…";
  cancel.textContent = "关闭";
  progress.textContent = "路由器正在处理订阅。关闭此窗口后，导入会继续。";
  progress.hidden = false;
  try {
    await action("import", { name: values.get("name").trim(), url }, () => {
      form.reset();
      dialog.close();
      if (state.page === "routing") {
        const profile = data.profiles.at(-1);
        state.wizard.profile = profile.id;
        state.wizard.line = profile.lines[0]?.name ?? "";
        state.step = 0;
      } else go("subscriptions");
      tell("订阅已导入。");
    }, showError);
  } finally {
    progress.hidden = true;
    cancel.textContent = "取消";
    submit.textContent = "导入订阅";
    submit.disabled = false;
  }
});

async function refreshLive(page) {
  if (page === "overview" || page === "devices") data.devices = await rpc("devices");
  if (page === "connections") data.connections = await rpc("connections");
  if (state.page === page) render();
}

new ResizeObserver(() => {
  if (state.page === "overview") drawChart();
}).observe(get("chart"));

let ticks = 0;
async function refresh() {
  try {
    if (!document.hidden && !changingJob) {
      if (!state.available || ticks % 8 === 0) await syncStatus(state.page === "overview");
      if (state.connected && state.page === "overview") {
        data.traffic.push(await rpc("traffic"));
        data.traffic = data.traffic.slice(-60);
        drawChart();
      }
      if (ticks % 6 === 0 && state.page !== "settings" && state.page !== "routing" && state.page !== "subscriptions") {
        if (state.page !== "devices" || !Object.keys(state.deviceDraft).length) await refreshLive(state.page);
      }
      ticks++;
    }
  } catch (error) {
    state.available = false;
    data.problem = error.message;
    get("platform").textContent = "服务不可用";
    if (state.page === "overview") renderOverview();
  } finally {
    setTimeout(refresh, state.available ? 1000 : 5000);
  }
}

const softwareCenterPage = /^\/?(?:Module_Softcenter|Main_Soft_center)\.asp$/i;
window.addEventListener("load", () => {
  if (typeof window.show_menu !== "function") return;
  window.show_menu(() => {
    const { tablink, tabtitle } = window;
    if (!Array.isArray(tablink) || !Array.isArray(tabtitle)) return;
    const index = tablink.findIndex((links) => Array.isArray(links) && links.some((link) => softwareCenterPage.test(link)));
    if (index < 0 || !Array.isArray(tabtitle[index]) || tablink[index].includes("Module_behoo.asp")) return;
    tablink[index].push("Module_behoo.asp");
    tabtitle[index].push("壁虎 Behoo");
  });
  const softwareCenterLink = Array.from(document.querySelectorAll("#mainMenu a, #subMenu a, #tabMenu a"))
    .find((link) => softwareCenterPage.test(link.pathname));
  if (softwareCenterLink) get("software-center-link").href = softwareCenterLink.pathname;
});

go("overview", false);
refresh();
})();
</script>
</body>
</html>
