#!/bin/sh
set -eu
export PATH=/bin:/sbin:/usr/sbin:/usr/bin:/koolshare/bin
home=/koolshare/behoo
run=/tmp/behoo-run
script=/koolshare/scripts/behoo_service.sh
hook=/jffs/scripts/firewall-start
mkdir -p "$run"
mkdir "$run/install.lock" 2>/dev/null || exit 1
tmp=
cleanup() {
    if [ -n "$tmp" ]; then rm -f "$tmp"; fi
    rmdir "$run/install.lock" 2>/dev/null || :
}
trap cleanup EXIT
cru d BehooWatchdog >/dev/null 2>&1 || :
if [ -x "$script" ]; then "$script" stop; fi
if [ -s "$home/kernel.path" ]; then
    kernel="$(cat "$home/kernel.path")"
    case "$kernel" in /tmp/mnt/*/mihomo|/mnt/*/mihomo) rm -f -- "$kernel" ;; esac
fi
if [ -f "$hook" ] && grep -q '^# BEGIN BEHOO FIREWALL$' "$hook"; then
    tmp="$("$home/behoo" temp-file /jffs/scripts 'firewall-start.behoo.*')"
    awk '/^# BEGIN BEHOO FIREWALL$/ { drop=1; next } /^# END BEHOO FIREWALL$/ { drop=0; next } !drop' "$hook" >"$tmp"
    chmod +x "$tmp"
    mv -f "$tmp" "$hook"
fi
rm -f /koolshare/init.d/S98behoo.sh /koolshare/init.d/N98behoo.sh /koolshare/webs/Module_behoo.asp /koolshare/res/icon-behoo.png
rm -f "$script" /koolshare/scripts/behoo_rpc.sh /koolshare/scripts/uninstall_behoo.sh
rm -f "$run/mihomo-exec"
rm -rf "$home"
for key in install version name title description; do dbus remove "softcenter_module_behoo_$key" || :; done
