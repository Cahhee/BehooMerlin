#!/bin/sh
set -u
export PATH=/bin:/sbin:/usr/sbin:/usr/bin:/koolshare/bin
home=/koolshare/behoo
run=/tmp/behoo-run
app="$home/behoo"
probe="${BEHOO_PROBE:-$app}"
start_log="$run/daemon-start.log"
core="$(cat "$home/kernel.path" 2>/dev/null || echo "$home/mihomo")"
umask 077

get_pid() {
    [ -x "$probe" ] && [ -s "$run/daemon.pid" ] || return 1
    pid="$("$probe" daemon-pid "$run" "$app" 2>/dev/null)"
}

start_error() {
    printf '[Behoo] %s\n' "$*" >&2
    return 1
}

show_start_log() {
    if [ -s "$start_log" ]; then cat "$start_log" >&2; fi
}

start() {
    if [ -d "$run/install.lock" ] && [ "${BEHOO_INSTALLING:-0}" != 1 ]; then return 0; fi
    if get_pid; then return 0; fi
    [ -x "$app" ] || { start_error "管理程序不可执行：$app"; return; }
    case "$core" in
        *.gz) [ -s "$core" ] || { start_error "压缩内核缺失或为空：$core"; return; } ;;
        *) [ -x "$core" ] || { start_error "内核不可执行：$core"; return; } ;;
    esac
    mkdir -p "$run" || return 1
    chmod 700 "$run" || return 1
    if ! ( : > "$start_log" ); then start_error "无法创建启动日志：$start_log"; return; fi
    (
        trap '' HUP
        exec "$app" serve -core "$core"
    ) </dev/null >"$start_log" 2>&1 &
    launcher=$!
    tries=0
    until get_pid; do
        if ! kill -0 "$launcher" 2>/dev/null; then
            wait "$launcher"
            status=$?
            show_start_log
            start_error "管理程序在就绪前退出，退出码 ${status}。日志：$start_log"
            return
        fi
        tries=$((tries+1))
        # The daemon may spend up to 40 seconds clearing stale firewall rules.
        if [ "$tries" -ge 45 ]; then
            kill -TERM "$launcher" 2>/dev/null || :
            show_start_log
            start_error "等待管理程序就绪超时。日志：$start_log"
            return
        fi
        sleep 1
    done
}

stop() {
    if get_pid; then
        kill -TERM "$pid"
        tries=0
        while get_pid; do
            tries=$((tries+1))
            [ "$tries" -lt 45 ] || return 1
            sleep 1
        done
    fi
    [ -x "$home/firewall.sh" ] || return 0
    "$home/firewall.sh" detach 2>/dev/null || return 1
    "$home/firewall.sh" unguard 2>/dev/null
}

case "${1:-}" in
    stop) stop ;;
    firewall|nat-start)
        if get_pid; then kill -HUP "$pid"; else start; fi ;;
    start|restart|watchdog|*)
        if get_pid; then
            case "$0" in */N98behoo.sh) kill -HUP "$pid" ;; esac
        else
            start
        fi ;;
esac
