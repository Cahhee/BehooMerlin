#!/bin/sh
set -eu
export PATH=/bin:/sbin:/usr/sbin:/usr/bin:/koolshare/bin
run="${BEHOO_RUN:-/tmp/behoo-run}"
chain=BEHOO_PROXY
filter=BEHOO_INPUT
mark=0x01000000/0x01000000
table=23172
priority=10172
redir=17991
tproxy=17992
dns=17993

wait_flag=
iptables -w -t filter -L INPUT -n >/dev/null 2>&1 && wait_flag=-w
ipt() { iptables $wait_flag "$@"; }

detach() {
    anchor="$(cat "$run/firewall-interface" 2>/dev/null || :)"
    for table_name in nat mangle; do
        if [ -n "$anchor" ]; then
            while ipt -t "$table_name" -D PREROUTING -i "$anchor" -j "$chain" >/dev/null 2>&1; do :; done
        fi
        if ipt -t "$table_name" -F "$chain" >/dev/null 2>&1; then ipt -t "$table_name" -X "$chain"; fi
    done
    rm -f "$run/firewall-interface"
    if [ -f "$run/route-owned" ]; then
        ip -4 rule del priority "$priority" fwmark "$mark" table "$table" 2>/dev/null || :
        ip -4 route del local 0.0.0.0/0 dev lo table "$table" 2>/dev/null || :
        rm -f "$run/route-owned"
    fi
}

unguard() {
    while ipt -D INPUT -j "$filter" >/dev/null 2>&1; do :; done
    if ipt -F "$filter" >/dev/null 2>&1; then ipt -X "$filter"; fi
}

guard() {
    incoming=$1
    kind=$2
    if ! ipt -nL "$filter" >/dev/null 2>&1; then ipt -N "$filter"; fi
    # Keep the existing guard until the new rules have been inserted.
    ipt -I "$filter" 1 -p tcp -m multiport --dports 17990,17991,17992,17993 -j DROP
    ipt -I "$filter" 1 -p udp -m multiport --dports 17990,17992,17993 -j DROP
    if [ "$kind" = manual ]; then
        ipt -I "$filter" 1 -i "$incoming" -p tcp --dport 17990 -j ACCEPT
        ipt -I "$filter" 1 -i "$incoming" -p udp --dport 17990 -j ACCEPT
    fi
    ipt -I "$filter" 1 -i lo -j RETURN
    if [ "$kind" != manual ]; then
        ipt -I "$filter" 2 -i "$incoming" -p tcp -m multiport --dports 17991,17993 -j ACCEPT
        ipt -I "$filter" 2 -i "$incoming" -p udp --dport 17993 -j ACCEPT
    fi
    stop_line=6
    if [ "$kind" = tproxy ]; then
        ipt -I "$filter" 2 -i "$incoming" -m mark --mark "$mark" -j ACCEPT
        stop_line=7
    fi
    # This stop rule keeps prior rules from granting access after a mode change.
    ipt -I "$filter" "$stop_line" -j RETURN
    if ! ipt -nL INPUT | awk -v chain="$filter" '$1 == chain { found=1 } END { exit !found }'; then
        ipt -I INPUT 1 -j "$filter"
    fi
    last="$(ipt -nL "$filter" --line-numbers | awk '$2 == "RETURN" && $1 > 1 {print $1; exit}')"
    while ipt -D "$filter" "$((last + 1))" >/dev/null 2>&1; do :; done
}

exemptions() {
    table_name=$1
    for network in 0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 240.0.0.0/4; do
        ipt -t "$table_name" -A "$chain" -d "$network" -j RETURN
    done
    ip -4 addr show | awk '$1 == "inet" {sub(/\/.*/, "", $2); print $2}' |
    while IFS= read -r address; do
        ipt -t "$table_name" -A "$chain" -d "$address/32" -j RETURN
    done
}

case "${1:-}" in
    detach) detach; exit ;;
    unguard) unguard; exit ;;
    probe)
        probe="BEHOO_TEST_$$"
        ipt -t mangle -N "$probe" || exit 1
        trap 'ipt -t mangle -F "$probe"; ipt -t mangle -X "$probe"' EXIT
        for proto in tcp udp; do
            ipt -t mangle -A "$probe" -p "$proto" -j TPROXY --on-port "$tproxy" --tproxy-mark "$mark" || exit 1
        done
        ip -4 rule show >/dev/null
        exit
        ;;
    guard|apply) ;;
    *) exit 2 ;;
esac

operation=$1
interface=$2
mode=$3
router=$4
shift 4
case "$interface" in ''|*[!a-zA-Z0-9_.:-]*) exit 2 ;; esac
case "$router" in ''|*[!0-9.]*) exit 2 ;; esac
case "$mode" in manual|tproxy|redirect) ;; *) exit 2 ;; esac
if [ "$operation" = guard ]; then guard "$interface" "$mode"; exit; fi

detach
trap 'detach' EXIT
if [ "$mode" = manual ] || [ "$#" -eq 0 ]; then trap - EXIT; exit; fi

printf "%s\n" "$interface" > "$run/firewall-interface"
ipt -t nat -N "$chain"
for mac do
    for proto in udp tcp; do
        # Only redirect requests aimed at the router DNS service.
        ipt -t nat -A "$chain" -m mac --mac-source "$mac" -d "$router/32" -p "$proto" --dport 53 -j REDIRECT --to-ports "$dns"
    done
done
exemptions nat
if [ "$mode" = redirect ]; then
    for mac do
        ipt -t nat -A "$chain" -m mac --mac-source "$mac" -p tcp -j REDIRECT --to-ports "$redir"
    done
else
    if ip -4 rule show | grep -Eq "^$priority:|lookup $table( |$)|fwmark 0x1000000"; then
        echo 'Behoo policy routing rule is in use' >&2
        exit 1
    fi
    if [ -n "$(ip -4 route show table "$table" 2>/dev/null || :)" ]; then
        echo 'Behoo routing table is in use' >&2
        exit 1
    fi
    : > "$run/route-owned"
    ip -4 route add local 0.0.0.0/0 dev lo table "$table"
    ip -4 rule add priority "$priority" fwmark "$mark" table "$table"
    ipt -t mangle -N "$chain"
    exemptions mangle
    for mac do
        for proto in tcp udp; do
            ipt -t mangle -A "$chain" -m mac --mac-source "$mac" -p "$proto" -j TPROXY --on-port "$tproxy" --tproxy-mark "$mark"
        done
    done
fi

# Intercepted packets retain their original port in TPROXY mode.
if [ "$mode" = tproxy ]; then
    ipt -t mangle -I PREROUTING 1 -i "$interface" -j "$chain"
fi
ipt -t nat -I PREROUTING 1 -i "$interface" -j "$chain"
trap - EXIT
