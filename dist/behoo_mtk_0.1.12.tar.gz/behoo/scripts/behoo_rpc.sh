#!/bin/sh
export KSROOT=/koolshare
export PATH=/bin:/koolshare/bin:/usr/sbin:/usr/bin:/sbin
case "${1:-}" in ''|*[!0-9]*) exit 2 ;; esac
payload="${2:-}"
. /koolshare/scripts/base.sh

# Keep the response path open even if the firmware dropped the request parameter.
case "$payload" in
    ''|*[!A-Za-z0-9_-]*) payload= ;;
esac
if [ -z "$payload" ] || [ "${#payload}" -gt 16384 ]; then
    result=eyJlcnJvciI6Iui9r-S7tuS4reW_g-S8oOmAkueahOivt-axguWPguaVsOS4jeWujOaVtOaIluaXoOaViOOAgiJ9
else
    # No subscription URLs or credentials are recorded in software center dbus.
    result="$(/koolshare/behoo/behoo rpc "$payload" 2>/dev/null)" || result=eyJlcnJvciI6IuWjgeiZjueuoeeQhuacjeWKoeacquWTjeW6lOOAgiJ9
fi
http_response "$result"
