#!/bin/sh
set -eu
export PATH=/bin:/sbin:/usr/sbin:/usr/bin:/koolshare/bin
umask 077
src="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
home=/koolshare/behoo
run=/tmp/behoo-run
service=/koolshare/scripts/behoo_service.sh
candidate_service="$src/scripts/behoo_service.sh"
jffs=/jffs/scripts/firewall-start

die() { printf '[Behoo] %s\n' "$*" >&2; exit 1; }

# Some firmware images ship BusyBox without the id applet.
effective_uid() {
    while read -r field real effective rest; do
        [ "$field" = 'Uid:' ] || continue
        case "$effective" in ''|*[!0-9]*) return 1 ;; esac
        printf '%s\n' "$effective"
        return 0
    done < /proc/self/status
    return 1
}

uid="$(effective_uid)" || die '无法从 /proc/self/status 读取当前进程权限。'
[ "$uid" = 0 ] || die '需要以 root 权限安装。'
[ -f /koolshare/scripts/base.sh ] && [ -d /koolshare/webs ] || die '需要已启用的软件中心。'

# Some firmware shells omit the command builtin.
find_dbus() {
    IFS=:
    for directory in $PATH; do
        if [ -f "$directory/dbus" ] && [ -x "$directory/dbus" ]; then
            printf '%s\n' "$directory/dbus"
            return 0
        fi
    done
    return 1
}
dbus_bin="$(find_dbus)" || die '软件中心缺少可执行的 dbus。'

read -r package version abi < "$src/platform"
[ -x "$src/bin/behoo" ] && [ -s "$src/bin/mihomo.gz" ] && [ -s "$src/bin/mihomo.size" ] || die '缺少插件服务或压缩内核。'
"$src/bin/behoo" version >/dev/null || die '插件服务无法在当前固件运行。'
# Some firmware also installs a hardware utility called sh on PATH.
detected="$(/bin/sh "$src/platform.sh" "$src/bin/behoo")" || die '当前固件用户态架构不受支持。'
case "$detected" in
    'arm armv7'|'hnd armv7'|'hnd_v8 arm64'|'qca armv7'|'mtk arm64'|'ipq32 armv7'|'ipq64 arm64') ;;
    *) die '固件平台检测返回了无效结果。' ;;
esac
[ "$detected" = "$package $abi" ] || die "当前固件是 ${detected}，请选择对应的离线包。"
[ -d /koolshare/scripts ] || die '软件中心脚本目录不可用。'
mkdir -p "$home" /koolshare/init.d "$run"
chmod 700 "$home" "$run"
mkdir "$run/install.lock" 2>/dev/null || die '已有安装或卸载任务正在执行。'
trap 'rmdir "$run/install.lock" 2>/dev/null || :' EXIT

previous_core="$(cat "$home/kernel.path" 2>/dev/null || :)"
core_dir="${BEHOO_STORAGE:-}"
if [ -z "$core_dir" ] && [ -n "$previous_core" ]; then
    core_dir="$(dirname "$previous_core")"
fi
[ -n "$core_dir" ] || core_dir="$home"
case "$core_dir" in
    "$home") ;;
    /tmp/mnt/*|/mnt/*)
        [ -d "$core_dir" ] && [ -w "$core_dir" ] || die '请先创建已挂载 USB 卷上的 Behoo 专用目录。'
        actual="$(CDPATH= cd -- "$core_dir" && pwd -P)"
        case "$actual" in /tmp/mnt/*|/mnt/*) core_dir="$actual" ;; *) die 'USB 路径不在挂载目录内。' ;; esac
        ;;
    *) die 'BEHOO_STORAGE 只能指向 /tmp/mnt 或 /mnt 下已挂载的专用目录。' ;;
esac
core_bytes="$(cat "$src/bin/mihomo.size")"
case "$core_bytes" in ''|*[!0-9]*) die '压缩内核的尺寸清单无效。' ;; esac
core_required=$(((core_bytes + 1023) / 1024 + 1024))
if [ "$core_dir" = "$home" ]; then
    core="$home/mihomo.gz"
    required="$("$src/bin/behoo" file-kib "$src/bin/mihomo.gz")" || die '无法读取压缩内核的大小。'
    required=$((required + 1024))
    tmp_available="$("$src/bin/behoo" free-kib "$run")" || die '无法获取 /tmp 可用空间。'
    [ "$tmp_available" -ge "$core_required" ] || die '/tmp 空间不足，无法解压 Mihomo。可改用 BEHOO_STORAGE 将内核解压到 USB。'
else
    core="$core_dir/mihomo"
    required="$core_required"
fi
# Retain the previous kernel while the candidate is staged and verified.
available="$("$src/bin/behoo" free-kib "$core_dir")" || die '无法获取目标存储容量。'
[ "$available" -ge "$required" ] || die '空间不足。请通过 SSH 指定已挂载 USB 上的 Behoo 专用目录。'
app_required="$("$src/bin/behoo" file-kib "$src/bin/behoo")" || die '无法读取管理服务的大小。'
app_required=$((app_required + 1024))
app_available="$("$src/bin/behoo" free-kib "$home")" || die '无法获取软件中心存储容量。'
if [ "$core_dir" = "$home" ]; then app_required=$((app_required + required)); fi
[ "$app_available" -ge "$app_required" ] || die '软件中心分区空间不足。'

stage=
staged_core=
replacement_started=0
installed=0
rollback() {
    if [ "$installed" = 0 ] && [ "$replacement_started" = 1 ]; then
        BEHOO_PROBE="$src/bin/behoo" "$candidate_service" stop >/dev/null 2>&1 || :
        for name in behoo kernel.path firewall.sh; do
            if [ -e "$stage/old/$name" ]; then mv -f "$stage/old/$name" "$home/$name"; else rm -f "$home/$name"; fi
        done
        if [ -e "$staged_core.previous" ]; then mv -f "$staged_core.previous" "$core"; else rm -f "$core"; fi
        [ ! -x "$home/behoo" ] || BEHOO_INSTALLING=1 BEHOO_PROBE="$src/bin/behoo" "$candidate_service" start >/dev/null 2>&1 || :
    fi
    if [ -n "$staged_core" ]; then rm -f "$staged_core" "$staged_core.previous"; fi
    if [ -n "$stage" ]; then rm -rf "$stage"; fi
    rmdir "$run/install.lock" 2>/dev/null || :
}
trap rollback EXIT
stage="$("$src/bin/behoo" temp-dir "$home" '.install.*')" || die '无法创建插件安装临时目录。'
staged_core="$("$src/bin/behoo" temp-file "$core_dir" '.behoo-mihomo.*')" || die '无法创建内核临时文件。'
mkdir "$stage/old"
cp "$src/bin/behoo" "$src/scripts/firewall.sh" "$stage"
chmod 700 "$stage/behoo" "$stage/firewall.sh"
if [ "$core_dir" = "$home" ]; then
    cp "$src/bin/mihomo.gz" "$staged_core"
    "$stage/behoo" verify-core "$src/bin/mihomo.gz" >/dev/null || die '无法解压 Mihomo 或启动控制接口。'
else
    "$stage/behoo" unpack-core "$src/bin/mihomo.gz" "$staged_core" || die '无法将内核解压到 USB。'
    "$stage/behoo" verify-core "$staged_core" >/dev/null || die 'Mihomo 无法从 USB 启动控制接口。'
fi
printf '%s\n' "$core" > "$stage/kernel.path"
BEHOO_PROBE="$src/bin/behoo" "$candidate_service" stop || die '旧版服务未能安全停止。'
for name in behoo kernel.path firewall.sh; do
    if [ -e "$home/$name" ]; then ln "$home/$name" "$stage/old/$name" || cp -p "$home/$name" "$stage/old/$name"; fi
done
if [ -e "$core" ]; then ln "$core" "$staged_core.previous" || cp -p "$core" "$staged_core.previous" || die '无法在该存储保留升级回滚副本。'; fi
replacement_started=1
mv -f "$staged_core" "$core"
for name in behoo kernel.path firewall.sh; do mv -f "$stage/$name" "$home/$name"; done
BEHOO_INSTALLING=1 "$candidate_service" start || die '壁虎管理服务未能启动。'

for name in behoo_rpc behoo_service; do
    cp "$src/scripts/$name.sh" "/koolshare/scripts/.$name.sh"
    chmod 755 "/koolshare/scripts/.$name.sh"
    mv -f "/koolshare/scripts/.$name.sh" "/koolshare/scripts/$name.sh"
done
cp "$src/webs/Module_behoo.asp" /koolshare/webs/.Module_behoo.asp
chmod 644 /koolshare/webs/.Module_behoo.asp
mv -f /koolshare/webs/.Module_behoo.asp /koolshare/webs/Module_behoo.asp
mkdir -p /koolshare/res
cp "$src/res/icon-behoo.png" /koolshare/res/icon-behoo.png
chmod 644 /koolshare/res/icon-behoo.png
cp "$src/uninstall.sh" /koolshare/scripts/uninstall_behoo.sh
chmod 755 /koolshare/scripts/uninstall_behoo.sh
ln -sf "$service" /koolshare/init.d/S98behoo.sh
ln -sf "$service" /koolshare/init.d/N98behoo.sh
if [ -d /jffs/scripts ] && [ "$(nvram get jffs2_scripts)" = 1 ]; then
    if [ ! -f "$jffs" ]; then printf '#!/bin/sh\n' > "$jffs"; fi
    if ! grep -q '^# BEGIN BEHOO FIREWALL$' "$jffs"; then
        printf '\n# BEGIN BEHOO FIREWALL\n/koolshare/scripts/behoo_service.sh firewall >/dev/null 2>&1 &\n# END BEHOO FIREWALL\n' >> "$jffs"
    fi
    chmod +x "$jffs"
fi
cru a BehooWatchdog "* * * * * $service watchdog" >/dev/null 2>&1 || :
"$dbus_bin" set "softcenter_module_behoo_name=behoo"
"$dbus_bin" set "softcenter_module_behoo_title=壁虎 Behoo"
"$dbus_bin" set "softcenter_module_behoo_description=Mihomo 局域网透明代理"
"$dbus_bin" set "softcenter_module_behoo_version=$version"
"$dbus_bin" set 'softcenter_module_behoo_install=1'
installed=1
case "$previous_core" in
    "$home/mihomo"|"$home/mihomo.gz")
        if [ "$previous_core" != "$core" ]; then rm -f "$previous_core"; fi ;;
esac
printf '[Behoo] 安装完成。请在软件中心打开壁虎。\n'
